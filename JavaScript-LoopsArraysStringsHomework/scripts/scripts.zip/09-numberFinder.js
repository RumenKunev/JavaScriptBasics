function findMostFreqNum(arr){
    var obj = {};
    var arrLength = arr.length;
    var i;
    var arrElement = arr[0];
    var objKey = '' + arrElement;
    obj[objKey] = 1;
    for (i = 1; i < arrLength; i += 1) {
        var arrElement = arr[i];
        var objKey = '' + arrElement;

            if (objKey === Object.keys(obj)) {
                obj[objKey] += 1;

            } else {
                obj[objKey] = 1;
            }


    }
    return obj;
}
console.log(findMostFreqNum([2,2,4,4,6,6,2]));
